<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class team_member extends Model
{
    //
}
